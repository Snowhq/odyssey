"use client";
import { useEffect, useState } from "react";

type Market = {
  id: string; question: string; category: string;
  expiresAt: string; resolved: boolean; outcome: string | null;
  yesTotal: number; noTotal: number; bets: any[];
};

export default function PortfolioPage() {
  const [markets, setMarkets] = useState<Market[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/predictions").then(r => r.json()).then(data => {
      setMarkets(Array.isArray(data) ? data.filter((m: Market) => m.bets.length > 0) : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const totalBet = markets.reduce((acc, m) => acc + m.bets.reduce((a, b) => a + b.amount, 0), 0);
  const activeBets = markets.filter(m => !m.resolved);
  const resolvedBets = markets.filter(m => m.resolved);

  function getOdds(m: Market) {
    const total = m.yesTotal + m.noTotal;
    if (total === 0) return { yes: 50, no: 50 };
    return { yes: Math.round((m.yesTotal / total) * 100), no: Math.round((m.noTotal / total) * 100) };
  }

  function potentialWin(m: Market, bet: any) {
    const total = m.yesTotal + m.noTotal;
    const pool = bet.side === "yes" ? m.yesTotal : m.noTotal;
    if (pool === 0) return (bet.amount * 2).toFixed(3);
    return ((bet.amount / pool) * total).toFixed(3);
  }

  return (
    <main style={{ minHeight: "100vh", background: "#000", color: "#fff" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Space+Mono:wght@400;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        a { text-decoration: none; color: inherit; }
        .serif { font-family: 'Playfair Display', Georgia, serif; }
        .mono { font-family: 'Space Mono', monospace; }
        .bet-row { border-bottom: 1px solid #111; transition: background 0.15s; }
        .bet-row:hover { background: #080808; }
      `}</style>

      <nav style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 48px", height: 56, borderBottom: "1px solid #1a1a1a", position: "sticky", top: 0, background: "rgba(0,0,0,0.95)", backdropFilter: "blur(16px)", zIndex: 100 }}>
        <a href="/"><img src="/logo.png" alt="Odyssey" style={{ height: "30px", width: "auto", filter: "brightness(0) invert(1)" }} /></a>
        <div style={{ display: "flex", gap: 32 }}>
          <a href="/predictions" style={{ color: "#555", fontSize: 13 }}>Markets</a>
          <a href="/hire" style={{ background: "#fff", color: "#000", padding: "8px 20px", fontSize: 12, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase" }}>Hire an agent →</a>
        </div>
      </nav>

      <section style={{ padding: "80px 48px 0", borderBottom: "1px solid #1a1a1a" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <p className="mono" style={{ fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: "0.2em", marginBottom: 20 }}>// portfolio</p>
          <h1 className="serif" style={{ fontSize: "clamp(52px,9vw,100px)", fontWeight: 900, letterSpacing: "-0.03em", lineHeight: 0.9, color: "#fff", marginBottom: 20 }}>
            My Bets.
          </h1>
          <p style={{ fontSize: 14, color: "#555", lineHeight: 1.7, paddingBottom: 48 }}>Your active and resolved prediction market positions.</p>
        </div>
      </section>

      <section style={{ borderBottom: "1px solid #1a1a1a" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(3,1fr)" }}>
          {[
            { label: "Total wagered", value: "$" + totalBet.toFixed(2), color: "#5555ff" },
            { label: "Active positions", value: activeBets.length.toString(), color: "#fff" },
            { label: "Resolved", value: resolvedBets.length.toString(), color: "#10b981" },
          ].map((s, i) => (
            <div key={s.label} style={{ padding: "40px 48px", borderRight: i < 2 ? "1px solid #1a1a1a" : "none" }}>
              <p className="mono" style={{ fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 12 }}>{s.label}</p>
              <p className="serif" style={{ fontSize: "clamp(28px,4vw,44px)", fontWeight: 700, color: s.color }}>{s.value}</p>
            </div>
          ))}
        </div>
      </section>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "64px 48px 100px" }}>
        {loading ? (
          <p className="mono" style={{ color: "#333", fontSize: 11, padding: "48px 0", letterSpacing: "0.1em" }}>Loading...</p>
        ) : markets.length === 0 ? (
          <div style={{ textAlign: "center", padding: "80px 0" }}>
            <p style={{ color: "#333", fontSize: 15, marginBottom: 24 }}>No bets placed yet.</p>
            <a href="/predictions" style={{ display: "inline-block", background: "#fff", color: "#000", padding: "10px 24px", fontSize: 12, fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase" }}>View markets →</a>
          </div>
        ) : (
          <>
            {activeBets.length > 0 && (
              <div style={{ marginBottom: 64 }}>
                <p className="mono" style={{ fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 32, paddingBottom: 16, borderBottom: "1px solid #1a1a1a" }}>Active positions</p>
                {activeBets.map(m => {
                  const odds = getOdds(m);
                  return m.bets.map((bet, i) => (
                    <a key={`${m.id}-${i}`} href={`/predictions/${m.id}`} className="bet-row" style={{ display: "grid", gridTemplateColumns: "1fr 120px 120px 120px", gap: 24, alignItems: "center", padding: "20px 0" }}>
                      <div>
                        <p style={{ fontSize: 14, color: "#ccc", fontWeight: 500, marginBottom: 6, lineHeight: 1.4 }}>{m.question}</p>
                        <p className="mono" style={{ fontSize: 10, color: "#333" }}>Expires {new Date(m.expiresAt).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="mono" style={{ fontSize: 10, color: "#444", marginBottom: 4 }}>Position</p>
                        <span style={{ background: bet.side === "yes" ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)", color: bet.side === "yes" ? "#10b981" : "#ef4444", padding: "4px 10px", fontSize: 11, fontWeight: 700, border: `1px solid ${bet.side === "yes" ? "rgba(16,185,129,0.2)" : "rgba(239,68,68,0.2)"}` }}>
                          {bet.side.toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="mono" style={{ fontSize: 10, color: "#444", marginBottom: 4 }}>Wagered</p>
                        <p className="serif" style={{ fontSize: 20, fontWeight: 700, color: "#fff" }}>${bet.amount.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="mono" style={{ fontSize: 10, color: "#444", marginBottom: 4 }}>To win</p>
                        <p className="serif" style={{ fontSize: 20, fontWeight: 700, color: "#10b981" }}>${potentialWin(m, bet)}</p>
                      </div>
                    </a>
                  ));
                })}
                <div style={{ borderTop: "1px solid #1a1a1a" }} />
              </div>
            )}

            {resolvedBets.length > 0 && (
              <div>
                <p className="mono" style={{ fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: "0.15em", marginBottom: 32, paddingBottom: 16, borderBottom: "1px solid #1a1a1a" }}>Resolved positions</p>
                {resolvedBets.map(m => {
                  return m.bets.map((bet, i) => {
                    const won = bet.side === m.outcome;
                    return (
                      <a key={`${m.id}-${i}`} href={`/predictions/${m.id}`} className="bet-row" style={{ display: "grid", gridTemplateColumns: "1fr 120px 120px 120px", gap: 24, alignItems: "center", padding: "20px 0" }}>
                        <div>
                          <p style={{ fontSize: 14, color: won ? "#ccc" : "#444", fontWeight: 500, marginBottom: 6, lineHeight: 1.4 }}>{m.question}</p>
                          <p className="mono" style={{ fontSize: 10, color: "#333" }}>Resolved {m.outcome?.toUpperCase()}</p>
                        </div>
                        <div>
                          <p className="mono" style={{ fontSize: 10, color: "#444", marginBottom: 4 }}>Position</p>
                          <span style={{ background: bet.side === "yes" ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)", color: bet.side === "yes" ? "#10b981" : "#ef4444", padding: "4px 10px", fontSize: 11, fontWeight: 700, border: `1px solid ${bet.side === "yes" ? "rgba(16,185,129,0.2)" : "rgba(239,68,68,0.2)"}` }}>
                            {bet.side.toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="mono" style={{ fontSize: 10, color: "#444", marginBottom: 4 }}>Wagered</p>
                          <p className="serif" style={{ fontSize: 20, fontWeight: 700, color: won ? "#fff" : "#333" }}>${bet.amount.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="mono" style={{ fontSize: 10, color: "#444", marginBottom: 4 }}>Result</p>
                          <p className="serif" style={{ fontSize: 20, fontWeight: 700, color: won ? "#10b981" : "#ef4444" }}>{won ? "Won ✓" : "Lost ✗"}</p>
                        </div>
                      </a>
                    );
                  });
                })}
                <div style={{ borderTop: "1px solid #1a1a1a" }} />
              </div>
            )}
          </>
        )}
      </div>
    </main>
  );
}