"use client";
import { useEffect, useState } from "react";

type Market = {
  id: string; question: string; category: string;
  createdAt: string; expiresAt: string; resolved: boolean;
  outcome: string | null; yesTotal: number; noTotal: number; bets: any[];
};

function timeLeft(expiresAt: string) {
  const diff = new Date(expiresAt).getTime() - Date.now();
  if (diff <= 0) return "Expired";
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  return d > 0 ? `${d}d left` : `${h}h left`;
}

const CAT: Record<string, { bg: string; color: string }> = {
  market:                { bg: "rgba(99,102,241,0.15)",  color: "#818cf8" },
  tech:                  { bg: "rgba(16,185,129,0.15)",  color: "#34d399" },
  business:              { bg: "rgba(245,158,11,0.15)",  color: "#fbbf24" },
  finance:               { bg: "rgba(99,102,241,0.15)",  color: "#818cf8" },
  crypto:                { bg: "rgba(251,191,36,0.15)",  color: "#fbbf24" },
  politics:              { bg: "rgba(239,68,68,0.15)",   color: "#f87171" },
  education:             { bg: "rgba(16,185,129,0.15)",  color: "#34d399" },
  entertainment:         { bg: "rgba(168,85,247,0.15)",  color: "#c084fc" },
  "entertainment/media": { bg: "rgba(168,85,247,0.15)",  color: "#c084fc" },
  publishing:            { bg: "rgba(236,72,153,0.15)",  color: "#f472b6" },
  "publishing/literature":{ bg: "rgba(236,72,153,0.15)", color: "#f472b6" },
  default:               { bg: "rgba(255,255,255,0.07)", color: "#6b7280" },
};

export default function PredictionsPage() {
  const [markets, setMarkets] = useState<Market[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "open" | "resolved" | "my bets">("all");

  useEffect(() => {
    fetch("/api/predictions").then(r => r.json())
      .then(d => { setMarkets(Array.isArray(d) ? d : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const getOdds = (m: Market) => {
    const total = m.yesTotal + m.noTotal;
    if (total === 0) return { yes: 50, no: 50, total: 0 };
    return { yes: Math.round((m.yesTotal / total) * 100), no: Math.round((m.noTotal / total) * 100), total };
  };

  const filtered = markets.filter(m => {
    if (filter === "open") return !m.resolved;
    if (filter === "resolved") return m.resolved;
    if (filter === "my bets") return m.bets.length > 0;
    return true;
  });

  const totalVol = markets.reduce((a, m) => a + m.yesTotal + m.noTotal, 0);

  return (
    <main style={{ minHeight: "100vh", background: "#000", color: "#fff" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Space+Mono:wght@400;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        a { text-decoration: none; color: inherit; }
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
        .serif { font-family: 'Playfair Display', Georgia, serif; }
        .mono { font-family: 'Space Mono', monospace; }
        .nav-a { color: #555; font-size: 13px; transition: color 0.2s; }
        .nav-a:hover { color: #fff; }
        .mcard { border: 1px solid #1a1a1a; background: #080808; transition: border-color 0.2s, transform 0.2s; display: flex; flex-direction: column; }
        .mcard:hover { border-color: #333; transform: translateY(-2px); }
        .tab-btn { cursor: pointer; font-family: 'Space Mono', monospace; font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; padding: 8px 18px; border: none; transition: all 0.15s; }
        .yes-btn { background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.25); color: #10b981; padding: 8px 16px; font-size: 11px; font-weight: 700; cursor: pointer; letter-spacing: 0.05em; transition: background 0.15s; font-family: inherit; }
        .yes-btn:hover { background: rgba(16,185,129,0.2); }
        .no-btn { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.25); color: #ef4444; padding: 8px 16px; font-size: 11px; font-weight: 700; cursor: pointer; letter-spacing: 0.05em; transition: background 0.15s; font-family: inherit; }
        .no-btn:hover { background: rgba(239,68,68,0.2); }
        .bar-yes { background: linear-gradient(90deg, #059669, #10b981); }
        .bar-no { background: linear-gradient(90deg, #b91c1c, #ef4444); }
        @keyframes fadeUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:none} }
      `}</style>

      <nav style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 48px", height: 56, borderBottom: "1px solid #1a1a1a", position: "sticky", top: 0, background: "rgba(0,0,0,0.95)", backdropFilter: "blur(16px)", zIndex: 100 }}>
        <a href="/"><img src="/logo.png" alt="Odyssey" style={{ height: "30px", width: "auto", filter: "brightness(0) invert(1)" }} /></a>
        <div style={{ display: "flex", gap: 32 }}>
          <a href="/ledger" className="nav-a">Ledger</a>
          <a href="/hire" style={{ background: "#fff", color: "#000", padding: "8px 20px", fontSize: 12, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase" }}>Hire an agent →</a>
        </div>
      </nav>

      {/* Header */}
      <section style={{ padding: "72px 48px 56px", borderBottom: "1px solid #1a1a1a" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 32, marginBottom: 40 }}>
            <div>
              <p className="mono" style={{ fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: "0.2em", marginBottom: 20 }}>// prediction markets</p>
              <h1 className="serif" style={{ fontSize: "clamp(44px,7vw,88px)", fontWeight: 900, letterSpacing: "-0.03em", lineHeight: 0.92, color: "#fff" }}>
                Prediction<br />Markets.
              </h1>
            </div>
            <div style={{ display: "flex", gap: 40, alignItems: "flex-end" }}>
              <div style={{ textAlign: "right" }}>
                <p className="mono" style={{ fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 8 }}>Volume</p>
                <p className="serif" style={{ fontSize: 36, fontWeight: 700, color: "#5555ff" }}>${totalVol.toFixed(2)}</p>
              </div>
              <div style={{ textAlign: "right" }}>
                <p className="mono" style={{ fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 8 }}>Markets</p>
                <p className="serif" style={{ fontSize: 36, fontWeight: 700, color: "#fff" }}>{markets.length}</p>
              </div>
            </div>
          </div>

          {/* Filter tabs */}
          <div style={{ display: "flex", gap: 0, borderBottom: "1px solid #1a1a1a", marginBottom: 0 }}>
            {(["all", "open", "resolved", "my bets"] as const).map(f => (
              <button key={f} className="tab-btn" onClick={() => setFilter(f)} style={{
                color: filter === f ? "#fff" : "#444",
                borderBottom: filter === f ? "2px solid #fff" : "2px solid transparent",
                background: "transparent",
              }}>{f}</button>
            ))}
          </div>
        </div>
      </section>

      {/* Markets grid */}
      <section style={{ padding: "48px 48px 100px" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto" }}>
          {loading ? (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
              {[0,1,2,3,4,5].map(i => (
                <div key={i} style={{ height: 220, background: "#080808", border: "1px solid #111", opacity: 1 - i * 0.12 }} />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div style={{ textAlign: "center", padding: "100px 0", borderTop: "1px solid #1a1a1a" }}>
              <p className="mono" style={{ color: "#333", fontSize: 11, letterSpacing: "0.1em", marginBottom: 24 }}>// no markets</p>
              <p style={{ color: "#333", fontSize: 15, marginBottom: 40 }}>Run a research job to generate prediction markets.</p>
              <a href="/hire" style={{ display: "inline-block", background: "#fff", color: "#000", padding: "12px 28px", fontSize: 12, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>Start a job →</a>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
              {filtered.map((m, idx) => {
                const odds = getOdds(m);
                const cat = CAT[m.category] || CAT.default;
                return (
                  <div key={m.id} className="mcard" style={{ animation: `fadeUp 0.3s ease ${idx * 0.04}s both` }}>
                    {/* Card top */}
                    <a href={`/predictions/${m.id}`} style={{ display: "block", padding: "24px 24px 20px", flex: 1 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                          <span className="mono" style={{ background: cat.bg, color: cat.color, padding: "3px 8px", fontSize: 9, letterSpacing: "0.08em", textTransform: "uppercase" }}>
                            {m.category}
                          </span>
                          {m.resolved && <span className="mono" style={{ background: "rgba(16,185,129,0.1)", color: "#10b981", padding: "3px 8px", fontSize: 9, letterSpacing: "0.08em" }}>✓ resolved</span>}
                        </div>
                        <span className="mono" style={{ fontSize: 9, color: "#333", letterSpacing: "0.05em", flexShrink: 0 }}>{timeLeft(m.expiresAt)}</span>
                      </div>

                      <p style={{ fontSize: 14, fontWeight: 500, color: "#ddd", lineHeight: 1.55, marginBottom: 20 }}>{m.question}</p>

                      {/* Odds bar */}
                      <div style={{ display: "flex", height: 3, marginBottom: 10, background: "#111" }}>
                        <div className="bar-yes" style={{ width: `${odds.yes}%` }} />
                        <div className="bar-no" style={{ width: `${odds.no}%` }} />
                      </div>

                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <div style={{ display: "flex", gap: 16 }}>
                          <span className="mono" style={{ fontSize: 11, color: "#10b981" }}>YES {odds.yes}%</span>
                          <span className="mono" style={{ fontSize: 11, color: "#ef4444" }}>NO {odds.no}%</span>
                        </div>
                        <span className="mono" style={{ fontSize: 9, color: "#333" }}>{m.bets.length} bets · ${odds.total.toFixed(2)}</span>
                      </div>
                    </a>

                    {/* Card bottom — bet buttons */}
                    {!m.resolved && (
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", borderTop: "1px solid #111" }}>
                        <a href={`/predictions/${m.id}`}>
                          <button className="yes-btn" style={{ width: "100%", borderRadius: 0, borderLeft: "none", borderBottom: "none", borderTop: "none" }}>
                            Buy YES
                          </button>
                        </a>
                        <a href={`/predictions/${m.id}`}>
                          <button className="no-btn" style={{ width: "100%", borderRadius: 0, borderRight: "none", borderBottom: "none", borderTop: "none" }}>
                            Buy NO
                          </button>
                        </a>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {!loading && markets.length > 0 && (
            <div style={{ marginTop: 48, textAlign: "center" }}>
              <a href="/hire" style={{ color: "#333", fontSize: 12, letterSpacing: "0.05em" }}>Generate more markets from a new research job →</a>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}