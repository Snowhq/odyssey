"use client";
import { useEffect, useState, Suspense } from "react";
import { useParams, useSearchParams } from "next/navigation";

type Bet = { side: string; amount: number; paidAt: string; txHash: string | null };
type Market = {
  id: string; question: string; category: string; brief: string;
  createdAt: string; expiresAt: string; resolved: boolean; outcome: string | null;
  yesTotal: number; noTotal: number; bets: Bet[];
};

const PRESETS = ["0.05", "0.10", "0.25", "0.50", "1.00"];

const CAT_STYLE: Record<string, { bg: string; color: string }> = {
  market:                 { bg: "rgba(99,102,241,0.15)",  color: "#818cf8" },
  tech:                   { bg: "rgba(16,185,129,0.15)",  color: "#34d399" },
  business:               { bg: "rgba(245,158,11,0.15)",  color: "#fbbf24" },
  finance:                { bg: "rgba(99,102,241,0.15)",  color: "#818cf8" },
  crypto:                 { bg: "rgba(251,191,36,0.15)",  color: "#fbbf24" },
  politics:               { bg: "rgba(239,68,68,0.15)",   color: "#f87171" },
  education:              { bg: "rgba(16,185,129,0.15)",  color: "#34d399" },
  entertainment:          { bg: "rgba(168,85,247,0.15)",  color: "#c084fc" },
  "entertainment/media":  { bg: "rgba(168,85,247,0.15)",  color: "#c084fc" },
  publishing:             { bg: "rgba(236,72,153,0.15)",  color: "#f472b6" },
  "publishing/literature":{ bg: "rgba(236,72,153,0.15)",  color: "#f472b6" },
  default:                { bg: "rgba(255,255,255,0.07)", color: "#6b7280" },
};

function MarketContent() {
  const params = useParams();
  const searchParams = useSearchParams();
  const id = params.id as string;

  const justBet = searchParams.get("success") === "true";
  const betSide = searchParams.get("bet");
  const betAmt  = searchParams.get("amount");

  const [market, setMarket]       = useState<Market | null>(null);
  const [loading, setLoading]     = useState(true);
  const [amount, setAmount]       = useState("0.10");
  const [placing, setPlacing]     = useState(false);
  const [error, setError]         = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [resolving, setResolving] = useState(false);

  function loadMarket() {
    fetch("/api/predictions")
      .then(r => r.json())
      .then(data => {
        const found = data.find((m: Market) => m.id === id);
        setMarket(found || null);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }

  useEffect(() => { loadMarket(); }, [id]);

  useEffect(() => {
    if (justBet && betSide && betAmt && !confirmed) {
      setConfirmed(true);
      fetch("/api/predictions/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ marketId: id, side: betSide, amount: parseFloat(betAmt) }),
      }).then(() => loadMarket());
    }
  }, [justBet, betSide, betAmt, id, confirmed]);

  async function placeBet(side: "yes" | "no") {
    setError("");
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt < 0.01) { setError("Minimum bet is $0.01 USDC"); return; }
    setPlacing(true);
    try {
      const res = await fetch("/api/predictions/bet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ marketId: id, side, amount: amt }),
      });
      const data = await res.json();
      if (data.redirectUrl) {
        const popup = window.open(
          data.redirectUrl,
          "locus-checkout",
          "width=500,height=700,left=" + (window.screenX + (window.outerWidth - 500) / 2) + ",top=" + (window.screenY + (window.outerHeight - 700) / 2)
        );
        const timer = setInterval(() => {
          try {
            const popupUrl = popup?.location?.href || "";
            if (popupUrl.includes("success=true")) {
              clearInterval(timer);
              popup?.close();
              setPlacing(false);
              fetch("/api/predictions/confirm", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ marketId: id, side, amount: amt }),
              }).then(() => loadMarket());
              return;
            }
          } catch {
            // Still on Locus domain — cross-origin, ignore
          }
          if (popup?.closed) {
            clearInterval(timer);
            setPlacing(false);
            loadMarket();
          }
        }, 500);
      } else {
        setError(data.error || "Something went wrong.");
        setPlacing(false);
      }
    } catch {
      setError("Could not connect to server.");
      setPlacing(false);
    }
  }

  async function resolveMarket(outcome: "yes" | "no") {
    setResolving(true);
    await fetch("/api/predictions/resolve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ marketId: id, outcome }),
    });
    setResolving(false);
    loadMarket();
  }

  if (loading) return (
    <main style={{ minHeight: "100vh", background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <p style={{ color: "#222", fontSize: 14 }}>Loading market...</p>
    </main>
  );

  if (!market) return (
    <main style={{ minHeight: "100vh", background: "#000", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16 }}>
      <p style={{ color: "#444", fontSize: 15 }}>Market not found.</p>
      <a href="/predictions" style={{ color: "#5555ff", fontSize: 13, fontWeight: 600 }}>← Back to markets</a>
    </main>
  );

  const total  = market.yesTotal + market.noTotal;
  const yesPct = total === 0 ? 50 : Math.round((market.yesTotal / total) * 100);
  const noPct  = 100 - yesPct;
  const cat    = CAT_STYLE[market.category] || CAT_STYLE.default;
  const isExpired = new Date(market.expiresAt).getTime() < Date.now();

  const potentialPayout = (side: "yes" | "no") => {
    const pool = side === "yes" ? market.yesTotal : market.noTotal;
    const mult = pool === 0 ? 2 : total / pool;
    return (parseFloat(amount || "0") * mult).toFixed(3);
  };

  return (
    <main style={{ minHeight: "100vh", background: "#000", color: "#fff", fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Space+Mono:wght@400;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        a { text-decoration: none; color: inherit; }
        .serif { font-family: 'Playfair Display', Georgia, serif; }
        .mono { font-family: 'Space Mono', monospace; }
        .yes-btn { background: rgba(16,185,129,0.1); border: 1px solid rgba(16,185,129,0.3); color: #10b981; }
        .yes-btn:hover:not(:disabled) { background: rgba(16,185,129,0.2) !important; }
        .no-btn { background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); color: #ef4444; }
        .no-btn:hover:not(:disabled) { background: rgba(239,68,68,0.2) !important; }
        .preset { cursor: pointer; font-family: inherit; transition: all 0.12s; }
        .preset:hover { border-color: #5555ff !important; color: #fff !important; }
        input[type=number]::-webkit-inner-spin-button { -webkit-appearance: none; }
        input[type=number] { -moz-appearance: textfield; }
        .bar-yes { background: linear-gradient(90deg, #059669, #10b981); transition: width 0.7s ease; }
        .bar-no  { background: linear-gradient(90deg, #b91c1c, #ef4444); transition: width 0.7s ease; }
        .resolve-btn { cursor: pointer; font-family: inherit; font-weight: 700; font-size: 12px; padding: 10px 20px; letter-spacing: 0.05em; text-transform: uppercase; transition: opacity 0.15s; border: none; }
        .resolve-btn:hover:not(:disabled) { opacity: 0.8; }
      `}</style>

      <nav style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 48px", height: 56, borderBottom: "1px solid #1a1a1a", position: "sticky", top: 0, background: "rgba(0,0,0,0.95)", backdropFilter: "blur(20px)", zIndex: 100 }}>
        <a href="/"><img src="/logo.png" alt="Odyssey" style={{ height: "30px", width: "auto", filter: "brightness(0) invert(1)" }} /></a>
        <div style={{ display: "flex", gap: 28, alignItems: "center" }}>
          <a href="/predictions" style={{ color: "#444", fontSize: 13 }}>All markets</a>
          <a href="/portfolio" style={{ color: "#444", fontSize: 13 }}>My bets</a>
        </div>
      </nav>

      <div style={{ maxWidth: 960, margin: "0 auto", padding: "48px 48px 100px" }}>
        <a href="/predictions" style={{ color: "#333", fontSize: 12, display: "inline-block", marginBottom: 40, letterSpacing: "0.05em" }}>← Markets</a>

        {/* Success banner */}
        {justBet && (
          <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", padding: "14px 20px", marginBottom: 32, display: "flex", alignItems: "center", gap: 12 }}>
            <span>✅</span>
            <div>
              <p style={{ color: "#10b981", fontWeight: 700, fontSize: 14 }}>Bet confirmed — {betSide?.toUpperCase()} ${betAmt} USDC</p>
              <p style={{ color: "rgba(16,185,129,0.5)", fontSize: 12, marginTop: 2 }}>Payment processed via Locus · recorded on Base</p>
            </div>
          </div>
        )}

        {/* Market header */}
        <div style={{ marginBottom: 40 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
            <span style={{ background: cat.bg, color: cat.color, padding: "3px 9px", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              {market.category}
            </span>
            {market.resolved && (
              <span style={{ background: "rgba(16,185,129,0.1)", color: "#10b981", padding: "3px 9px", fontSize: 10, fontWeight: 700 }}>
                ✓ Resolved — {market.outcome?.toUpperCase()} won
              </span>
            )}
            {!market.resolved && isExpired && (
              <span style={{ background: "rgba(245,158,11,0.1)", color: "#f59e0b", padding: "3px 9px", fontSize: 10, fontWeight: 700 }}>
                Expired — pending resolution
              </span>
            )}
          </div>
          <h1 className="serif" style={{ fontSize: "clamp(22px,3.5vw,40px)", fontWeight: 700, lineHeight: 1.2, color: "#f0f0f0", letterSpacing: "-0.02em", marginBottom: 12 }}>
            {market.question}
          </h1>
          <p className="mono" style={{ color: "#2a2a2a", fontSize: 10, letterSpacing: "0.05em" }}>
            From: {market.brief} · Expires {new Date(market.expiresAt).toLocaleDateString()}
          </p>
        </div>

        {/* Resolve controls — only show if expired and not resolved */}
        {!market.resolved && isExpired && (
          <div style={{ background: "#080808", border: "1px solid #2a2a1a", padding: "20px 24px", marginBottom: 28, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
            <div>
              <p className="mono" style={{ fontSize: 10, color: "#f59e0b", textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 4 }}>// market expired</p>
              <p style={{ color: "#555", fontSize: 13 }}>Resolve this market to pay out winners.</p>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button
                className="resolve-btn"
                disabled={resolving}
                onClick={() => resolveMarket("yes")}
                style={{ background: "#10b981", color: "#000", opacity: resolving ? 0.5 : 1 }}
              >
                {resolving ? "..." : "Resolve YES ✓"}
              </button>
              <button
                className="resolve-btn"
                disabled={resolving}
                onClick={() => resolveMarket("no")}
                style={{ background: "#ef4444", color: "#fff", opacity: resolving ? 0.5 : 1 }}
              >
                {resolving ? "..." : "Resolve NO ✗"}
              </button>
            </div>
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 24, alignItems: "start" }}>

          {/* Left — stats + chart + bets */}
          <div>
            {/* Stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginBottom: 20 }}>
              {[
                { label: "Total pot",  value: `$${total.toFixed(2)}`,           color: "#fff"    },
                { label: "YES pool",   value: `$${market.yesTotal.toFixed(2)}`, color: "#10b981" },
                { label: "NO pool",    value: `$${market.noTotal.toFixed(2)}`,  color: "#ef4444" },
              ].map(s => (
                <div key={s.label} style={{ background: "#080808", padding: 16, border: "1px solid #1a1a1a" }}>
                  <p className="mono" style={{ color: "#2a2a2a", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8 }}>{s.label}</p>
                  <p className="serif" style={{ fontSize: 22, fontWeight: 700, color: s.color }}>{s.value}</p>
                </div>
              ))}
            </div>

            {/* Odds */}
            <div style={{ background: "#080808", padding: 24, border: "1px solid #1a1a1a", marginBottom: 16 }}>
              <p className="mono" style={{ color: "#333", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 16 }}>Current odds</p>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
                <span className="serif" style={{ fontSize: 32, fontWeight: 700, color: "#10b981" }}>{yesPct}%</span>
                <span className="serif" style={{ fontSize: 32, fontWeight: 700, color: "#ef4444" }}>{noPct}%</span>
              </div>
              <div style={{ display: "flex", height: 6, overflow: "hidden", background: "#111", gap: 2 }}>
                <div className="bar-yes" style={{ width: `${yesPct}%` }} />
                <div className="bar-no"  style={{ width: `${noPct}%`  }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10 }}>
                <span className="mono" style={{ fontSize: 10, color: "#444" }}>YES · ${market.yesTotal.toFixed(2)}</span>
                <span className="mono" style={{ fontSize: 10, color: "#444" }}>NO · ${market.noTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Bet history */}
            {market.bets.length > 0 && (
              <div style={{ background: "#080808", border: "1px solid #1a1a1a", overflow: "hidden" }}>
                <div style={{ padding: "12px 20px", borderBottom: "1px solid #111" }}>
                  <p className="mono" style={{ color: "#333", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.1em" }}>
                    Recent bets · {market.bets.length} total
                  </p>
                </div>
                {[...market.bets].reverse().slice(0, 8).map((bet, i) => (
                  <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 20px", borderBottom: i < 7 ? "1px solid #0a0a0a" : "none" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 6, height: 6, borderRadius: "50%", background: bet.side === "yes" ? "#10b981" : "#ef4444" }} />
                      <span className="mono" style={{ fontSize: 11, fontWeight: 700, color: bet.side === "yes" ? "#10b981" : "#ef4444" }}>
                        {bet.side.toUpperCase()}
                      </span>
                    </div>
                    <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
                      <span className="serif" style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>${bet.amount.toFixed(2)}</span>
                      <span className="mono" style={{ fontSize: 9, color: "#222" }}>{new Date(bet.paidAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right — bet widget */}
          <div>
            {market.resolved ? (
              <div style={{ background: "#080808", padding: 28, border: "1px solid rgba(16,185,129,0.2)", textAlign: "center" }}>
                <p style={{ fontSize: 32, marginBottom: 16 }}>🏁</p>
                <p className="serif" style={{ fontSize: 20, fontWeight: 700, color: "#10b981", marginBottom: 8 }}>Market Resolved</p>
                <p className="mono" style={{ fontSize: 12, color: "#555", letterSpacing: "0.08em", textTransform: "uppercase" }}>{market.outcome} won</p>
                {total > 0 && (
                  <div style={{ marginTop: 20, padding: "16px", background: "rgba(16,185,129,0.05)", border: "1px solid rgba(16,185,129,0.1)" }}>
                    <p className="mono" style={{ fontSize: 9, color: "#444", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8 }}>Total pot paid out</p>
                    <p className="serif" style={{ fontSize: 24, fontWeight: 700, color: "#10b981" }}>${total.toFixed(2)}</p>
                  </div>
                )}
              </div>
            ) : (
              <div style={{ background: "#080808", padding: 24, border: "1px solid #1a1a1a", position: "sticky", top: 72 }}>
                <p className="mono" style={{ fontSize: 10, color: "#444", textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 20 }}>// place your bet</p>

                <p className="mono" style={{ color: "#2a2a2a", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8 }}>Amount (USDC)</p>
                <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 10 }}>
                  {PRESETS.map(p => (
                    <button key={p} className="preset" onClick={() => setAmount(p)} style={{
                      background: amount === p ? "#13132a" : "#111",
                      border: amount === p ? "1px solid #5555ff" : "1px solid #1a1a1a",
                      color: amount === p ? "#818cf8" : "#333",
                      padding: "6px 10px", fontSize: 11, fontWeight: 700, fontFamily: "inherit",
                    }}>${p}</button>
                  ))}
                </div>
                <input
                  type="number" value={amount} onChange={e => setAmount(e.target.value)}
                  min="0.01" step="0.01" placeholder="Custom"
                  style={{ width: "100%", background: "#111", border: "1px solid #1a1a1a", padding: "10px 14px", color: "#fff", fontSize: 14, outline: "none", fontFamily: "inherit", marginBottom: 20 }}
                />

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 20 }}>
                  <div style={{ background: "rgba(16,185,129,0.04)", border: "1px solid rgba(16,185,129,0.1)", padding: "10px 12px" }}>
                    <p className="mono" style={{ color: "rgba(16,185,129,0.5)", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>If YES wins</p>
                    <p className="serif" style={{ color: "#10b981", fontSize: 16, fontWeight: 700 }}>${potentialPayout("yes")}</p>
                  </div>
                  <div style={{ background: "rgba(239,68,68,0.04)", border: "1px solid rgba(239,68,68,0.1)", padding: "10px 12px" }}>
                    <p className="mono" style={{ color: "rgba(239,68,68,0.5)", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 4 }}>If NO wins</p>
                    <p className="serif" style={{ color: "#ef4444", fontSize: 16, fontWeight: 700 }}>${potentialPayout("no")}</p>
                  </div>
                </div>

                {error && (
                  <p className="mono" style={{ color: "#ef4444", fontSize: 10, marginBottom: 14, background: "rgba(239,68,68,0.06)", padding: "8px 12px" }}>
                    {error}
                  </p>
                )}

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                  <button className="yes-btn" onClick={() => placeBet("yes")} disabled={placing}
                    style={{ padding: 14, fontSize: 13, fontWeight: 800, cursor: placing ? "not-allowed" : "pointer", opacity: placing ? 0.5 : 1, fontFamily: "inherit", transition: "all 0.15s" }}>
                    {placing ? "..." : "Buy YES"}
                  </button>
                  <button className="no-btn" onClick={() => placeBet("no")} disabled={placing}
                    style={{ padding: 14, fontSize: 13, fontWeight: 800, cursor: placing ? "not-allowed" : "pointer", opacity: placing ? 0.5 : 1, fontFamily: "inherit", transition: "all 0.15s" }}>
                    {placing ? "..." : "Buy NO"}
                  </button>
                </div>

                <p className="mono" style={{ color: "#1a1a1a", fontSize: 9, textAlign: "center", marginTop: 14, letterSpacing: "0.05em" }}>
                  Payment via Locus · USDC on Base
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

export default function MarketPage() {
  return <Suspense><MarketContent /></Suspense>;
}